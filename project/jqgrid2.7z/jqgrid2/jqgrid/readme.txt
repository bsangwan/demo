jqGrid Examples.

To make this work you must create database griddemo (or what you want).
Enter the appropiate information in dbconfig.php.
Execute the database.sql script in MySQL server.
Copy the files to web server and open jqgrid.html via web browser.

how to run jqgrid demo official demo?

1、i download http://www.trirand.com/blog/jqgrid/downloads/jqgrid_demo40.zip

2、followed readme.txt 
3、in browser http://127.0.0.1/demo/project/jqgrid_demo40/36ajaxing.html

4、


